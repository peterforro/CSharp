﻿


namespace SeekAndArchive.Modules.Seeker {

    enum SearchType {
        RECURSIVE, BUILTIN, DFS
    }

}
